package com.psl.hibernate.main;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.hibernateDemo.bean.Skill;
import com.psl.hibernateDemo.bean.Student;

public class Main {

	public static void main(String[] args) {
		
		Student student1 = new Student();
		student1.setName("Sona");
		
		
		Student student2= new Student();
		student2.setName("MOna");
		
		Student student3= new Student();
		student2.setName("Rani");
		
		
	
	/*	List<Skill> skillList = new ArrayList<Skill>();*/
		
		Skill skill1 = new Skill();
		Skill skill2 = new Skill();
		Skill skill3 = new Skill();
		
		skill1.setName("Java");
		skill2.setName("JavaScript");
		skill3.setName("Hibernate");
		
		
		skill1.setVersion(1.8);
		skill2.setVersion(3.0);
		skill3.setVersion(5.2);
		
	
		
		student1.setSkill(skill1);
		student2.setSkill(skill2);
		student3.setSkill(skill3);
		
/*		skillList.add(skill1);
		skillList.add(skill2);
		skillList.add(skill3);*/
			
		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		
		Session session =factory.openSession();
		
		session.beginTransaction();
		

	/*	session.save(skill1);
		session.save(skill2);
		session.save(skill3);*/
		
		session.save(student1);
		session.save(student2);
		session.save(student3);
		
		

		session.save(skill1);
		
		
		session.getTransaction().commit();
		
		session.close();
		
	}
}
