package com.psl.hibernateDemo.bean;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name ="Skill_details")
public class Skill {

	@Id
	//@GeneratedValue( strategy = GenerationType.AUTO)
	
	
/*	@GeneratedValue(generator="gen")
    @GenericGenerator(name="gen", strategy="foreign",parameters=@Parameter(name="property", value="student"))*/
	@Column(name ="Skill_id")
	private int skillId;
	
	@Column(name = "skill_name")
	private String name ;
	
	@Column(name ="version")
	private double version;
	
	@OneToMany(mappedBy = "skill", cascade = CascadeType.ALL)
	private Collection<Student> student = new ArrayList<Student>();
	

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}
/*
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}*/

	public Skill(int skillId, String name, double version) {
		super();
		this.skillId = skillId;
		this.name = name;
		this.version = version;
	
	}

	public Collection<Student> getStudent() {
		return student;
	}

	public void setStudent(Collection<Student> student) {
		this.student = student;
	}

	public Skill() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
